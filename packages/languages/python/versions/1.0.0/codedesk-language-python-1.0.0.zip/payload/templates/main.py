print("Code Desk Python package works.")
