print("Hello from CodeDesk!")
