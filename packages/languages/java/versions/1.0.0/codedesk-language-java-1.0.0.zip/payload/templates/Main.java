public class Main {
    public static void main(String[] args) {
        System.out.println("Code Desk Java package works.");
    }
}
