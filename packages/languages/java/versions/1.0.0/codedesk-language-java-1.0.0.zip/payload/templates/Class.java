public class ${ClassName} {
}
