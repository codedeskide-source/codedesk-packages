public enum EnumName {
    VALUE
}
