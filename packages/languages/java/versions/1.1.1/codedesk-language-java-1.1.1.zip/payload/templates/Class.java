public class ClassName {

}
