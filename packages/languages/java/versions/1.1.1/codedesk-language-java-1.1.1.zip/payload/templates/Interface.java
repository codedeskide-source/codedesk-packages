public interface InterfaceName {

}
