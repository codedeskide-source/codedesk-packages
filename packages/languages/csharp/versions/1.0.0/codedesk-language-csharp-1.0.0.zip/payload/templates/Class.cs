public sealed class CodeDeskExample
{
}
