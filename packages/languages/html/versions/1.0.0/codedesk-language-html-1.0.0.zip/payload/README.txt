HTML package test payload for Code Desk 0.1.3.
