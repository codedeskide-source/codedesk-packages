Used to verify that installed compiler metadata is readable.
